﻿#target photoshop

app.bringToFront();

var originalRulerUnits = preferences.rulerUnits;
preferences.rulerUnits = Units.PIXELS;
preferences.typeUnits = TypeUnits.PIXELS;

var cleanDocumentName = "";
var targetImageFolders;
var actualPath  = "";
var textInfos    = "";
var baseDoc     = app.activeDocument;
var docWidth    = baseDoc.width.value;
var docHeight   = baseDoc.height.value;
var stackorder  = 0;
var parentObj = "";
var layerData;

var layerReadCount = 0;
var totalLayerCount = baseDoc.layers.length;

var win, windowResource;
var createProgressWindow, progressWindow;

var exportType = "WIDGETS";

// create a string to hold the data
var str ="<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
// add header line1
str += "<psd width=\"" + docWidth + "\" height=\"" + docHeight + "\">\n";

function cLayer(doc, layer) 
{
    this.layerWidth = layer.bounds[2].value - layer.bounds[0].value;
    this.layerHeight = layer.bounds[3].value - layer.bounds[1].value;

    this.middleCenterX = this.layerWidth / 2 + layer.bounds[0].value;
    this.middleCenterY = this.layerHeight / 2 + layer.bounds[1].value;

    this.center = this.middleCenterX + ", " + this.middleCenterY;


    return this;
}
function getActiveLayerID()
{
   var d = getActiveLayerDescriptor();
   return d.getInteger(cTID('LyrI'));
}

function cTID(s) {return app.charIDToTypeID(s);}
function sTID(s) {return app.stringIDToTypeID(s);}
function getActiveLayerDescriptor() {
   var ref = new ActionReference();
   ref.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
   return executeActionGet(ref);
}


function newDocFromLayer( curDoc, newDocName, layer )
{
    var newDoc = app.documents.add( curDoc.width, curDoc.height, curDoc.resolution, newDocName , NewDocumentMode.RGB, DocumentFill.TRANSPARENT); 
    newDoc.activeLayer.isBackgroundLayer = false;
    app.activeDocument = curDoc; 
    layer.duplicate( newDoc ); 
    app.activeDocument = newDoc;
    return app.activeDocument;
}
function RemoveLayerSetsFromObject(pTargetObj, pRemoveInvisible)
{
    var arrToRemove = [];
    for(var i = 0; i < pTargetObj.layers[0].layers.length; i++)
    {
        if(pTargetObj.layers[0].layers[i].typename == "LayerSet")
        {
            arrToRemove.push(pTargetObj.layers[0].layers[i]);
        }
        else
        {
            if(pRemoveInvisible)
            {
                if(pTargetObj.layers[0].layers[i].visible == false)
                {
                    arrToRemove.push(pTargetObj.layers[0].layers[i]);
                }
            }
        }
    }
    for(var i = 0; i < arrToRemove.length; i++)
    {
        arrToRemove[i].remove();
    }
}
function CloseAndSaveAsPNG(pDoc)
{
    var pngSaveOptions = new PNGSaveOptions();
    pDoc.trim(TrimType.TRANSPARENT);

    var validName = pDoc.name.replace(/[^a-z0-9]/gi, '_').toLowerCase();
    
    pDoc.saveAs(new File(targetImageFolders+validName+'.png'), pngSaveOptions, true, Extension.LOWERCASE);
    pDoc.close(SaveOptions.DONOTSAVECHANGES);
}

function ExportSpriteData(pTargetObj, pPath)
{
    var tParentName = GetParentName (pPath);
    var tSourceName = pTargetObj.name;    
    var tLayerID = getActiveLayerID();
    if(exportType == "WIDGETS")    
    {
        if(tParentName=="")
        {
            tSourceName = pTargetObj.name;
        }
        else
        {
            tSourceName = tParentName+"_"+pTargetObj.name;
        }    
    }
    var newDoc = newDocFromLayer(baseDoc, tSourceName, pTargetObj);
    layerData = cLayer(newDoc, newDoc.layers[0]);
    
    if(exportType == "WIDGETS")
        RemoveLayerSetsFromObject(newDoc, true)
    
    layerReadCount++;
    str += "<layer type='SPRITE'> \n";
    str += "        <name>"+pTargetObj.name+"</name>\n";
    str += "        <path>"+ pPath +"</path>\n";
    str += "        <posX>"+ layerData.middleCenterX +"</posX>\n";
    str += "        <posY>"+ layerData.middleCenterY +"</posY>\n";
    str += "        <source>"+ tSourceName+".png"+"</source>\n";
    str += "        <layerID>"+ tLayerID +"</layerID>\n"
    str += "</layer> \n";
    
    CloseAndSaveAsPNG(newDoc);
}
function ExportSlicedSpriteData(pTargetObj, pPath)
{
    var tLayerID = getActiveLayerID();
    var tParentName = GetParentName (pPath);
    var tSourceName = pTargetObj.name;    
    
    if(exportType == "WIDGETS")    
    {
        if(tParentName=="")
        {
            tSourceName = pTargetObj.name;
        }
        else
        {
            tSourceName = tParentName+"_"+pTargetObj.name;
        }    
    }
    var newDoc = newDocFromLayer(baseDoc, tSourceName, pTargetObj);
    layerData = cLayer(newDoc, newDoc.layers[0]);
    
    if(exportType == "WIDGETS")
        RemoveLayerSetsFromObject(newDoc, true)
    
    layerReadCount++;
    str += "<layer type='SLICED_SPRITE'> \n";
    str += "        <name>"+pTargetObj.name+"</name>\n";
    str += "        <path>"+ pPath +"</path>\n";
    str += "        <posX>"+ layerData.middleCenterX +"</posX>\n";
    str += "        <posY>"+ layerData.middleCenterY +"</posY>\n";
    str += "        <width>"+ layerData.layerWidth +"</width>\n";
    str += "        <height>"+ layerData.layerHeight +"</height>\n";
    str += "        <source>"+ tSourceName+".png"+"</source>\n";
    str += "        <layerID>"+ tLayerID +"</layerID>\n"
    str += "</layer> \n";
    
    CloseAndSaveAsPNG(newDoc);
}
function ExportAnchor(pDoc, pTargetObj, pPath)
{
    var tLayerID = getActiveLayerID();
    layerData = cLayer(pDoc, pTargetObj);
    
    layerReadCount
    str += "<layer type='ANCHOR'> \n";
    str += "        <name>"+pTargetObj.name+"</name>\n";
    str += "        <path>"+ pPath +"</path>\n";
    str += "        <posX>"+ layerData.middleCenterX +"</posX>\n";
    str += "        <posY>"+ layerData.middleCenterY +"</posY>\n";
    str += "        <layerID>"+ tLayerID +"</layerID>\n";
    str += "</layer> \n";
}
function ExportButton(pTargetObj, pPath)
{
    var tLayerID = getActiveLayerID();
    
    var newDoc = newDocFromLayer(baseDoc, pTargetObj.name, pTargetObj);
    layerData = cLayer(newDoc, newDoc.layers[0]);
    
    layerReadCount+=newDoc.layerSets[0].layerSets.length;
    str += "<layer type='IMAGEBUTTON'> \n";
    str += "        <name>"+pTargetObj.name+"</name>\n";
    str += "        <path>"+ pPath +"</path>\n";
    str += "        <posX>"+ layerData.middleCenterX +"</posX>\n";
    str += "        <posY>"+ layerData.middleCenterY +"</posY>\n";
    str += "        <layerID>"+ tLayerID +"</layerID>\n";
    str += "        <states> \n";
    
    
    for(var i = 0; i < newDoc.layerSets[0].layerSets.length; i++)
    {
        
        if(newDoc.layerSets[0].layerSets[i].name.toLowerCase() == "hover")
        {
            var tName = pTargetObj.name+"_hover";
            newDoc.layerSets[0].layerSets[i].name = tName;
            ExportSprite(newDoc, newDoc.layerSets[0].layerSets[i]);
            str += "                <hover>"+ newDoc.layerSets[0].layerSets[i].name+".png"+"</hover>\n";
        }
        else if(newDoc.layerSets[0].layerSets[i].name.toLowerCase() == "pressed")
        {
            var tName = pTargetObj.name+"_pressed";
            newDoc.layerSets[0].layerSets[i].name = tName;
            ExportSprite(newDoc, newDoc.layerSets[0].layerSets[i]);
            str += "                <pressed>"+ newDoc.layerSets[0].layerSets[i].name+".png"+"</pressed>\n";
        }
        else if(newDoc.layerSets[0].layerSets[i].name.toLowerCase() == "idle")
        {
            var tName = pTargetObj.name+"idle";
            newDoc.layerSets[0].layerSets[i].name = tName;
            ExportSprite(newDoc, newDoc.layerSets[0].layerSets[i]);
            str += "                <idle>"+ newDoc.layerSets[0].layerSets[i].name+".png"+"</idle>\n";
        }
        else if(newDoc.layerSets[0].layerSets[i].name.toLowerCase() == "disabled")
        {
            var tName = pTargetObj.name+"disabled";
            newDoc.layerSets[0].layerSets[i].name = tName;
            ExportSprite(newDoc, newDoc.layerSets[0].layerSets[i]);
            str += "                <disabled>"+ newDoc.layerSets[0].layerSets[i].name+".png"+"</disabled>\n";
        }
    }
    str += "        </states>\n";
    str += "</layer> \n";
    newDoc.close(SaveOptions.DONOTSAVECHANGES);
}
function ExportSlicedButton(pTargetObj, pPath)
{
    var tLayerID = getActiveLayerID();
    
    var newDoc = newDocFromLayer(baseDoc, pTargetObj.name, pTargetObj);
    layerData = cLayer(newDoc, newDoc.layers[0]);
    
    str += "<layer type='SLICED_IMAGEBUTTON'> \n";
    str += "        <name>"+pTargetObj.name+"</name>\n";
    str += "        <path>"+ pPath +"</path>\n";
    str += "        <posX>"+ layerData.middleCenterX +"</posX>\n";
    str += "        <posY>"+ layerData.middleCenterY +"</posY>\n";
    str += "        <width>"+ layerData.layerWidth +"</width>\n";
    str += "        <height>"+ layerData.layerHeight +"</height>\n";
    str += "        <layerID>"+ tLayerID +"</layerID>\n";
    str += "        <states> \n";
    
    layerReadCount+=newDoc.layerSets[0].layerSets.length;
    for(var i = 0; i < newDoc.layerSets[0].layerSets.length; i++)
    {
        
        if(newDoc.layerSets[0].layerSets[i].name.toLowerCase() == "hover")
        {
            var tName = pTargetObj.name+"_hover";
            newDoc.layerSets[0].layerSets[i].name = tName;
            ExportSprite(newDoc, newDoc.layerSets[0].layerSets[i]);
            str += "                <hover>"+ newDoc.layerSets[0].layerSets[i].name+".png"+"</hover>\n";
        }
        else if(newDoc.layerSets[0].layerSets[i].name.toLowerCase() == "pressed")
        {
            var tName = pTargetObj.name+"_pressed";
            newDoc.layerSets[0].layerSets[i].name = tName;
            ExportSprite(newDoc, newDoc.layerSets[0].layerSets[i]);
            str += "                <pressed>"+ newDoc.layerSets[0].layerSets[i].name+".png"+"</pressed>\n";
        }
        else if(newDoc.layerSets[0].layerSets[i].name.toLowerCase() == "idle")
        {
            var tName = pTargetObj.name+"idle";
            newDoc.layerSets[0].layerSets[i].name = tName;
            ExportSprite(newDoc, newDoc.layerSets[0].layerSets[i]);
            str += "                <idle>"+ newDoc.layerSets[0].layerSets[i].name+".png"+"</idle>\n";
        }
        else if(newDoc.layerSets[0].layerSets[i].name.toLowerCase() == "disabled")
        {
            var tName = pTargetObj.name+"disabled";
            newDoc.layerSets[0].layerSets[i].name = tName;
            ExportSprite(newDoc, newDoc.layerSets[0].layerSets[i]);
            str += "                <disabled>"+ newDoc.layerSets[0].layerSets[i].name+".png"+"</disabled>\n";
        }
    }
    str += "        </states>\n";
    str += "</layer> \n";
    newDoc.close(SaveOptions.DONOTSAVECHANGES);
}

function ExportCheckBox(pTargetObj, pPath)
{
    var tLayerID = getActiveLayerID();
    
    var newDoc = newDocFromLayer(baseDoc, pTargetObj.name, pTargetObj);
    layerData = cLayer(newDoc, newDoc.layers[0]);
    
    
    str += "<layer type='CHECKBOX'> \n";
    str += "        <name>"+pTargetObj.name+"</name>\n";
    str += "        <path>"+ pPath +"</path>\n";
    str += "        <posX>"+ layerData.middleCenterX +"</posX>\n";
    str += "        <posY>"+ layerData.middleCenterY +"</posY>\n";
    str += "        <layerID>"+ tLayerID +"</layerID>\n";
    str += "        <states> \n";
    layerReadCount+=newDoc.layerSets[0].layerSets.length;
    for(var i = 0; i < newDoc.layerSets[0].layerSets.length; i++)
    {
        if(newDoc.layerSets[0].layerSets[i].name.toLowerCase() == "checkmark")
        {
            var tName = pTargetObj.name+"_checkmark";
            newDoc.layerSets[0].layerSets[i].name = tName;
            ExportSprite(newDoc, newDoc.layerSets[0].layerSets[i]);
            str += "                <checkmark>"+ newDoc.layerSets[0].layerSets[i].name+".png"+"</checkmark>\n";
        }
        else if(newDoc.layerSets[0].layerSets[i].name.toLowerCase() == "background")
        {
            var tName = pTargetObj.name+"_background";
            newDoc.layerSets[0].layerSets[i].name = tName;
            ExportSprite(newDoc, newDoc.layerSets[0].layerSets[i]);
            str += "                <background>"+ newDoc.layerSets[0].layerSets[i].name+".png"+"</background>\n";
        }
    }
    str += "        </states>\n";
    str += "</layer> \n";
    newDoc.close(SaveOptions.DONOTSAVECHANGES);
}

function ExportTextLabel(pTargetObj, pPath)
{
    var tLayerID = getActiveLayerID();
    $.writeln ("Layer ID: "+ tLayerID);    
    
    var newDoc  = newDocFromLayer(baseDoc, pTargetObj.name, pTargetObj);
    layerData   = cLayer(newDoc, newDoc.layers[0]);
    var tPrefix = newDoc.layers[0].name.substring(0,4) ;
    var tLayer  = newDoc.layers[0].layers[0];

    if( tLayer.kind == LayerKind.TEXT )
    {
        layerReadCount+=1;
        var tText   = tLayer.textItem;
        var tSize   = new Number( tText.size );
        tSize       = Math.round (tSize);
        var tName   = newDoc.layers[0].name;
        tName       = tName.substring(4);

        var tType = tPrefix == "txt_" ? "TEXT_LABEL" : "INPUT_TEXT";

        str += "<layer type='"+ tType +"'> \n";
        str += "        <name>"+pTargetObj.name+"</name>\n";
        str += "        <path>"+ pPath +"</path>\n";
        str += "        <posX>"+ layerData.middleCenterX +"</posX>\n";
        str += "        <posY>"+ layerData.middleCenterY +"</posY>\n";
        str += "        <fontName>"+ tName +"</fontName>\n";
        str += "        <fontSize>"+ tSize +"</fontSize>\n";
        str += "        <fontColor>"+ tText.color.rgb.red +";"+ tText.color.rgb.green +";"+ tText.color.rgb.blue +"</fontColor>\n";
        str += "        <contents>"+ tText.contents +"</contents>\n";
        str += "        <layerID>"+ tLayerID +"</layerID>\n";
        str += "</layer>\n";
    }
    newDoc.close(SaveOptions.DONOTSAVECHANGES);

}
function ExportSlider(pTargetObj, pPath)
{
    var tLayerID = getActiveLayerID();
    
    var newDoc = newDocFromLayer(baseDoc, pTargetObj.name, pTargetObj);
    layerData = cLayer(newDoc, newDoc.layers[0]);
    
    str += "<layer type='SLIDER'> \n";
    str += "        <name>"+pTargetObj.name+"</name>\n";
    str += "        <path>"+ pPath +"</path>\n";
    str += "        <posX>"+ layerData.middleCenterX +"</posX>\n";
    str += "        <posY>"+ layerData.middleCenterY +"</posY>\n";
    str += "        <layerID>"+ tLayerID +"</layerID>\n";
    str += "        <states> \n";
    layerReadCount += newDoc.layerSets[0].layerSets.length;
    for(var i = 0; i < newDoc.layerSets[0].layerSets.length; i++)
    {
        if(newDoc.layerSets[0].layerSets[i].name.toLowerCase() == "thumb")
        {
            var tName = pTargetObj.name+"_thumb";
            newDoc.layerSets[0].layerSets[i].name = tName;
            ExportSprite(newDoc, newDoc.layerSets[0].layerSets[i]);
            str += "                <thumb>"+ newDoc.layerSets[0].layerSets[i].name+".png"+"</thumb>\n";
        }
        else if(newDoc.layerSets[0].layerSets[i].name.toLowerCase() == "background")
        {
            var tName = pTargetObj.name+"_background";
            newDoc.layerSets[0].layerSets[i].name = tName;
            ExportSprite(newDoc, newDoc.layerSets[0].layerSets[i]);
            str += "                <background>"+ newDoc.layerSets[0].layerSets[i].name+".png"+"</background>\n";
        }
        else if(newDoc.layerSets[0].layerSets[i].name.toLowerCase() == "foreground")
        {
            var tName = pTargetObj.name+"_foreground";
            newDoc.layerSets[0].layerSets[i].name = tName;
            ExportSprite(newDoc, newDoc.layerSets[0].layerSets[i]);
            str += "                <foreground>"+ newDoc.layerSets[0].layerSets[i].name+".png"+"</foreground>\n";
        }
    }
    str += "        </states>\n";
    str += "</layer> \n";
    newDoc.close(SaveOptions.DONOTSAVECHANGES);
}

function ExportProgressBar(pTargetObj, pPath)
{
    var tLayerID = getActiveLayerID();
    
    var newDoc = newDocFromLayer(baseDoc, pTargetObj.name, pTargetObj);
    layerData = cLayer(newDoc, newDoc.layers[0]);
    
    str += "<layer type='PROGRESSBAR'> \n";
    str += "        <name>"+pTargetObj.name+"</name>\n";
    str += "        <path>"+ pPath +"</path>\n";
    str += "        <posX>"+ layerData.middleCenterX +"</posX>\n";
    str += "        <posY>"+ layerData.middleCenterY +"</posY>\n";
    str += "        <layerID>"+ tLayerID +"</layerID>\n";
    str += "        <states> \n";
    layerReadCount+=newDoc.layerSets[0].layerSets.length;    
    for(var i = 0; i < newDoc.layerSets[0].layerSets.length; i++)
    {
        if(newDoc.layerSets[0].layerSets[i].name.toLowerCase() == "background")
        {
            var tName = pTargetObj.name+"_background";
            newDoc.layerSets[0].layerSets[i].name = tName;
            ExportSprite(newDoc, newDoc.layerSets[0].layerSets[i]);
            str += "                <background>"+ newDoc.layerSets[0].layerSets[i].name+".png"+"</background>\n";
        }
        else if(newDoc.layerSets[0].layerSets[i].name.toLowerCase() == "foreground")
        {
            var tName = pTargetObj.name+"_foreground";
            newDoc.layerSets[0].layerSets[i].name = tName;
            ExportSprite(newDoc, newDoc.layerSets[0].layerSets[i]);
            str += "                <foreground>"+ newDoc.layerSets[0].layerSets[i].name+".png"+"</foreground>\n";
        }
    }
    str += "        </states>\n";
    str += "</layer> \n";
    newDoc.close(SaveOptions.DONOTSAVECHANGES);
}

function ExportClippingPanel(pDoc, pTargetObj, pPath)
{
    layerReadCount++;
    var tLayerID = getActiveLayerID();
    layerData = cLayer(pDoc, pTargetObj);
    
    var tClippingAreaLayer = null;
    for(var i = (pTargetObj.layerSets.length-1); i >= 0 ; i--)
    {
        var tClippingAreaLayer = pTargetObj.layerSets[i];

        // if find a layer named "clipping-area" stop the search, 
        // if no layer was found, get the lastest layer to be the area...
        if(tClippingAreaLayer.name.toLowerCase() == "clipping-area")
            break;
    }
    var tClippingData = cLayer(pDoc, tClippingAreaLayer);


    str += "<layer type='CLIPPING'> \n";
    str += "        <name>"+pTargetObj.name+"</name>\n";
    str += "        <path>"+ pPath +"</path>\n";
    str += "        <posX>"+ layerData.middleCenterX +"</posX>\n";
    str += "        <posY>"+ layerData.middleCenterY +"</posY>\n";
    str += "        <clippingX>"+ tClippingData.layerWidth +"</clippingX>\n";
    str += "        <clippingY>"+ tClippingData.layerHeight +"</clippingY>\n";
    str += "        <layerID>"+ tLayerID +"</layerID>\n";
    str += "</layer> \n";
}

function GetParentName(pPath)
{
    if(pPath.substring(0, pPath.length-1) == "/")
        pPath = pPath.substring(0, pPath.length-1);
        
    var strPathLeng = pPath.length;
    var lastIndex = pPath.lastIndexOf ("/");
    if(lastIndex > -1)
    {
        pPath = pPath.substring ((lastIndex+1), strPathLeng);
    }

    return pPath;
}

function ExportSprite(pDoc, pTargetObj)
{
    var newDoc = newDocFromLayer(pDoc, pTargetObj.name, pTargetObj);
    layerData = cLayer(newDoc, newDoc.layers[0]);
    
    CloseAndSaveAsPNG(newDoc);
}

function ReadGroup(pTargetGroup, pPath)
{
   
    if(exportType == "WIDGETS")
    {
        totalLayerCount += pTargetGroup.layerSets.length;
        for(var i = (pTargetGroup.layerSets.length-1); i >= 0 ; i--)
        {
             var tmpObj = pTargetGroup.layerSets[i];
            baseDoc.activeLayer = tmpObj;
            
            progressWindow.bar.value = (layerReadCount/totalLayerCount)*100;
            progressWindow.update();
                  
            
            if(tmpObj.name.substring(0, 5) == "ibtn_")
            {
                ExportButton(tmpObj, pPath);
            }
            else if(tmpObj.name.substring(0, 8) == "ibtnslc_" )
            {
                ExportSlicedButton(tmpObj, pPath);
            }
            else if(tmpObj.name.substring(0, 4) == "txt_" )
            {
                ExportTextLabel(tmpObj, pPath);
            }
            else if(tmpObj.name.substring(0, 4) == "inp_" )
            {
                ExportTextLabel(tmpObj, pPath);
            }
            else if(tmpObj.name.substring(0, 4) == "ckb_" )
            {
                ExportCheckBox(tmpObj, pPath);
            }
            else if(tmpObj.name.substring(0, 4) == "sld_" )
            {
                ExportSlider(tmpObj, pPath);
            }
            else if(tmpObj.name.substring(0, 5) == "pgsb_" )
            {
                ExportProgressBar(tmpObj, pPath);
            }
            else
            {
                if(tmpObj.artLayers.length > 0)
                {
                    if(tmpObj.name.substring(0, 4) == "slc_" )
                    {
                        ExportSlicedSpriteData(tmpObj, pPath);
                    }
                    else
                    {
                        ExportSpriteData(tmpObj, pPath);
                    }
                }
                else if(tmpObj.name.substring(0, 5) == "clip_" )
                {
                    ExportClippingPanel(pTargetGroup, tmpObj, pPath);
                }
                else
                {
                    ExportAnchor(pTargetGroup, tmpObj, pPath);
                }
                if(tmpObj.layerSets.length > 0)
                {
                    var target="";
                    if(pPath == "")
                    {
                        target = tmpObj.name;
                     }
                    else
                    {
                        target= pPath+"/"+tmpObj.name;
                    }
                    ReadGroup(tmpObj, target);
                }
            }
        }
    }
    else if(exportType == "SPRITES")
    {
        totalLayerCount += pTargetGroup.layerSets.length;
         for(var i = (pTargetGroup.layerSets.length-1); i >= 0 ; i--)
        {
            
            var tmpObj = pTargetGroup.layerSets[i];
            baseDoc.activeLayer = tmpObj;
            
            var target = "";
            if(pPath == "")
            {
                target = tmpObj.name;
             }
            else
            {
                target= pPath+"/"+tmpObj.name;
            }
            ExportAnchor(pTargetGroup, pTargetGroup.layerSets[i], pPath);
            ReadGroup(tmpObj, target);
        }
        totalLayerCount += pTargetGroup.artLayers.length;
        for(var i = (pTargetGroup.artLayers.length-1); i >= 0; i--)
        {
            var tmpObj = pTargetGroup.artLayers[i];
            baseDoc.activeLayer = tmpObj;
            
            ExportSpriteData(tmpObj, pPath);
        }
        /*
        var theLayers = collectVisibleLayers(pTargetGroup, allLayers)
        // create a history state;
       myDocument.quickMaskMode = true;
       myDocument.quickMaskMode = false;
       var theState = myDocument.activeHistoryState;

        for (var m = 0; m < theLayers.length; m++) 
        {
            myDocument.artLayers.add();
            var theLayer = theLayers[m];
            hideOthers (theLayer, myDocument);
            deleteHiddenLayers ();
            savePNG (myDocument, theFolder, theLayer.name)
            myDocument.activeHistoryState = theState;
        };*/
    }
}

windowResource = "dialog {  \
    orientation: 'column', \
    alignChildren: ['fill', 'top'],  \
    preferredSize:[140, 60], \
    text: 'FastGUI Photoshop Exporter',  \
    margins:15, \
    \
    bottomGroup: Group{ \
        cancelButton: Button { text: 'Cancel', properties:{name:'cancel'}, size: [120,24], alignment:['right', 'center'] }, \
        exportAllAsSprite: Button { text: 'Export Sprites', properties:{name:'exportsprites'}, size: [120,24], alignment:['right', 'center'] }, \
        exportWidgets: Button { text: 'Export Widgets', properties:{name:'exportwidgets'}, size: [120,24], alignment:['right', 'center'] }, \
    }\
}"

win = new Window(windowResource);

win.bottomGroup.cancelButton.onClick = function() 
{
  return win.close();
};
win.bottomGroup.exportAllAsSprite.onClick = function() 
{
    exportType = "SPRITES";
    StartFolder();
};
win.bottomGroup.exportWidgets.onClick = function() {
    exportType = "WIDGETS";
    StartFolder();
};

function StartFolder()
{
    win.close();
    var theFolder    = Folder.selectDialog ("Select the target folder:");

    if (theFolder) 
    {
        progressWindow = createProgressWindow("Please wait...", undefined, 0, 100); 
        progressWindow.show();
        cleanDocumentName = app.activeDocument.name.match(/([^\.]+)/)[1];
        
        var TargetFolder = new Folder(theFolder+'/'+cleanDocumentName+'/');
        TargetFolder.create();     
        
        var folder = new Folder(TargetFolder+"/Images");
        folder.create();
        targetImageFolders = TargetFolder+"/Images/" ;
        
        ReadGroup(baseDoc, "");
        // Use this to export XML file to same directory where PSD file is located
        var mySourceFilePath = TargetFolder + "/";
        // create a reference to a file for output
        var csvFile = new File(mySourceFilePath.toString().match(/([^\.]+)/)[1] + "FastGUIData.xml");
        // open the file, write the data, then close the file
        csvFile.open('w');
        csvFile.writeln(str + "</psd>");
        csvFile.close();
        preferences.rulerUnits = originalRulerUnits;
        // Confirm that operation has completed
        alert("Operation Complete!" + "\n" + "Layer coordinates were successfully exported to:" + "\n" + "\n" + mySourceFilePath.toString().match(/([^\.]+)/)[1] + app.activeDocument.name.match(/([^\.]+)/)[1] + ".xml");
    }
}

createProgressWindow = function(title, message, min, max) {
  var win;
  win = new Window('palette', title);
  win.bar = win.add('progressbar', undefined, min, max);
  win.bar.preferredSize = [300, 20];
  win.stProgress = win.add("statictext");
  win.stProgress.preferredSize.width = 200;
 
  return win;
};


win.show();



/*
// 2012, use it at your own risk;
#target photoshop;
if (app.documents.length > 0) {
var myDocument = app.activeDocument;
// select folder;
var theFolder = Folder.selectDialog ("select folder");
if (theFolder) {
   var theLayers = collectVisibleLayers(myDocument, []);
// create a history state;
   myDocument.quickMaskMode = true;
   myDocument.quickMaskMode = false;
   var theState = myDocument.activeHistoryState;
// process the visible layers;
   for (var m = 0; m < theLayers.length; m++) {
      myDocument.artLayers.add();
      var theLayer = theLayers[m];
      hideOthers (theLayer, myDocument);
      deleteHiddenLayers ();
      savePNG (myDocument, theFolder, theLayer.name)
      myDocument.activeHistoryState = theState;
      };
   }
};
////// function to png //////
function savePNG (myDocument, docPath, basename) {
// weboptions;
var webOptions = new ExportOptionsSaveForWeb();
webOptions.format = SaveDocumentType.PNG;
webOptions.PNG8 = false;   
webOptions.transparency = true;
webOptions.interlaced = 0;
webOptions.includeProfile = false;
webOptions.optimized = true;
myDocument.exportDocument(new File(docPath+"/"+basename+".png"), ExportType.SAVEFORWEB, webOptions);
};
////// function collect all layers //////
function collectVisibleLayers (theParent, allLayers) {
   if (!allLayers) {var allLayers = new Array} 
   else {};
   for (var m = theParent.layers.length - 1; m >= 0;m--) {
      var theLayer = theParent.layers[m];
      if (theLayer.typename == "ArtLayer") {
         if (theLayer.visible == true) {
            allLayers.push(theLayer)
            }
         }
// apply the function to layersets;
      else {
         allLayers = (collectVisibleLayers(theLayer, allLayers))
         }
      };
   return allLayers
   };
////// delete hidden layers //////
function deleteHiddenLayers () {
try {
var id26 = charIDToTypeID( "Dlt " );
var desc6 = new ActionDescriptor();
var id27 = charIDToTypeID( "null" );
var ref6 = new ActionReference();
var id28 = charIDToTypeID( "Lyr " );
var id29 = charIDToTypeID( "Ordn" );
var id30 = stringIDToTypeID( "hidden" );
ref6.putEnumerated( id28, id29, id30 );
desc6.putReference( id27, ref6 );
executeAction( id26, desc6, DialogModes.NO );
} catch (e) {}
};
////// toggle visibility of others //////
function hideOthers (theLayer, myDocument) {
myDocument.activeLayer = theLayer;
// =======================================================
var idShw = charIDToTypeID( "Shw " );
    var desc10 = new ActionDescriptor();
    var idnull = charIDToTypeID( "null" );
        var list4 = new ActionList();
            var ref7 = new ActionReference();
            var idLyr = charIDToTypeID( "Lyr " );
            var idOrdn = charIDToTypeID( "Ordn" );
            var idTrgt = charIDToTypeID( "Trgt" );
            ref7.putEnumerated( idLyr, idOrdn, idTrgt );
        list4.putReference( ref7 );
    desc10.putList( idnull, list4 );
    var idTglO = charIDToTypeID( "TglO" );
    desc10.putBoolean( idTglO, true );
executeAction( idShw, desc10, DialogModes.NO );
};
}
*/
