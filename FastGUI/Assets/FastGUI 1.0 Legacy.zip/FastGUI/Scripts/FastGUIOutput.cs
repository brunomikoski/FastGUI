using UnityEngine;
using System.Collections;
using System.Collections.Generic;


public class FastGUIOutput : MonoBehaviour 
{
	public Dictionary<int, int> references = new Dictionary<int, int>();
}
